# 🧠 Image Caption Generator — Backend

Flask API powered by Hugging Face `nlpconnect/vit-gpt2-image-captioning`.

## Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

The server starts at **http://localhost:5000**.

> **First run** downloads the ViT-GPT2 model (~900 MB) from Hugging Face automatically.

---

## API Reference

### `GET /health`
Health check.

**Response**
```json
{ "status": "ok", "message": "Caption API is running 🚀" }
```

---

### `POST /generate-caption`

Generate a caption for an uploaded image.

**Option A — multipart/form-data**
| Field   | Type   | Required | Description                           |
|---------|--------|----------|---------------------------------------|
| image   | File   | ✅        | Image file (JPG / PNG / WEBP / GIF)   |
| style   | String | ❌        | `normal` \| `instagram` \| `funny`    |

**Option B — JSON**
```json
{
  "imageBase64": "<base64-encoded image (with or without data-URL prefix)>",
  "style": "instagram",
  "imageName": "sunset.jpg"
}
```

**Response**
```json
{
  "caption": "a dog sitting on a beach at sunset ✨📸",
  "style": "instagram",
  "imageName": "sunset.jpg"
}
```

---

### `GET /history`
Returns the 20 most recent captions.

---

### `DELETE /history/<id>`
Deletes a caption history record.

---

## Project Structure

```
backend/
├── app.py           # Main Flask application
├── requirements.txt # Python dependencies
└── captions.db      # SQLite database (auto-created on first run)
```
