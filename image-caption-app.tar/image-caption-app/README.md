# 🖼️ Caption Lab — AI Image Caption Generator

A full-stack web app that uses **ViT-GPT2** (Hugging Face) to generate captions for any image in three styles: Normal, Instagram, and Funny.

```
image-caption-app/
├── backend/
│   ├── app.py              # Flask API (caption generation, history, auth)
│   ├── requirements.txt    # Python dependencies
│   └── README.md           # Backend API reference
└── frontend/
    ├── index.html
    ├── vite.config.js
    ├── tailwind.config.js
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── index.css
        ├── components/
        │   ├── ImageDropzone.jsx   # Drag-and-drop upload UI
        │   ├── StylePicker.jsx     # Normal / Instagram / Funny selector
        │   ├── CaptionBox.jsx      # Result display + copy/download
        │   └── HistoryPanel.jsx    # Slide-out history drawer
        ├── hooks/
        │   └── useCaption.js       # Caption generation state machine
        └── utils/
            └── api.js              # Fetch wrappers for the Flask API
```

---

## 🚀 Quick Start

### 1. Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

> **First run** automatically downloads the ViT-GPT2 model (~900 MB).  
> The server starts on **http://localhost:5000**.

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

> App opens at **http://localhost:5173**.  
> API calls are proxied to Flask via Vite's dev server — no CORS config needed.

---

## ✨ Features

| Feature | Details |
|---|---|
| Drag & drop upload | Accepts JPG, PNG, WEBP, GIF |
| AI captioning | `nlpconnect/vit-gpt2-image-captioning` via Hugging Face Transformers |
| Caption styles | Normal · Instagram (emojis + hashtags) · Funny (meme-style) |
| Copy to clipboard | One-click copy with success feedback |
| Download as .txt | Saves caption to your device |
| Regenerate | Re-run the model with the same or different style |
| Caption history | Persistent SQLite store, viewable in a slide-out drawer |
| Responsive design | Works on mobile and desktop |

---

## 🛠 Tech Stack

| Layer | Tech |
|---|---|
| Frontend | React 18 + Vite + Tailwind CSS |
| Backend | Python 3.10+ · Flask · Flask-SQLAlchemy |
| AI Model | `nlpconnect/vit-gpt2-image-captioning` (Hugging Face) |
| Database | SQLite (auto-created) |

---

## 🔮 Extending the project

- **Multi-language**: add `Helsinki-NLP/opus-mt-en-*` translation after captioning
- **User auth**: add `flask-login` + a `User` model, gate `/history` per user
- **Better captions**: swap ViT-GPT2 for `Salesforce/blip2-opt-2.7b` for richer results
- **Deploy**: Dockerize with `docker-compose`, deploy frontend to Vercel and backend to Railway
